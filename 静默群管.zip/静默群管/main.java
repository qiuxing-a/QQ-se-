//腻了，不知道写java的尽头是什么
//在这感谢云汐,派大星,鹿子零,冷雨,陌然五位大佬
//玩java的路上磕磕绊绊,令我成长了许多
//刚开始是二改自己玩,觉得自己很强
//到后来慢慢接触,懵懂的函数,代码,参数与修不完的bug
//就这样吧,最后打一次广告
//食言闲聊群:813255889
//食言模块群:829597480
//别在群里开脚本，我谢谢你们
//可能还会完善一些脚本,看命运吧
//好用记得分享😡😡😡
//好用记得分享😡😡😡
//好用记得分享😡😡😡
//可以二改，出问题你找我你没(  )

public String post(String url,String params) {
        try {
            URL urlObjUrl=new URL(url);
            URLConnection connection =urlObjUrl.openConnection();
            connection.setDoOutput(true);
            OutputStream os=connection.getOutputStream();
            os.write(params.getBytes());
            os.close();
            InputStream iStream=connection.getInputStream();
            byte[] b=new byte[1024];
            int len;
            StringBuilder sb=new StringBuilder();
            while ((len=iStream.read(b))!=-1) {
                sb.append(new String(b,0,len));
            }
            return sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public String get(String url)
{
	StringBuffer buffer = new StringBuffer();
	InputStreamReader isr = null;
	try
	{
		URL urlObj = new URL(url);
		URLConnection uc = urlObj.openConnection();
		uc.setConnectTimeout(10000);
		uc.setReadTimeout(10000);
		isr = new InputStreamReader(uc.getInputStream(), "utf-8");
		BufferedReader reader = new BufferedReader(isr); //缓冲
		String line;
		while((line = reader.readLine()) != null)
		{
			buffer.append(line + "\n");
		}
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		try
		{
			if(null != isr)
			{
				isr.close();
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	if(buffer.length() == 0) return buffer.toString();
	buffer.delete(buffer.length() - 1, buffer.length());
	return buffer.toString();
}

    addItem("没有菜单静默触发","食言");
    public void 食言(int type,String peerUid,String nickName)
    {
	    if(getString(peerUid,"牛").equals("1")){
	        putString(peerUid,"牛","0");
	        Toast("你点你吗呢");
	    }else{
	        putString(peerUid,"牛","1");
	        Toast("你点你吗呢");
	    }
    }

public void onMsg(Object data){
String quntext = data.msg;
String qun = data.peerUid;
String uin = data.user;
String qq = myUin;
if(quntext.startsWith("我要头衔")){
setGroupMemberTitle(qun,uin,quntext.substring(4));
}
if(quntext.startsWith("设置头衔@")&&uin.equals(qq)){
String at=data.atList.get(0);
int str=quntext.lastIndexOf(" ")+1;
String text=quntext.substring(str);
setGroupMemberTitle(qun,at,text);
}

if(quntext.startsWith("踢@") && uin.equals(qq))
{
        String at = data.atList.get(0);
        kickGroup(qun, at, true);
}

if(uin.equals(qq)&&quntext.equals("全禁"))

{
shutUpAll(qun, true);
}
if(uin.equals(qq)&&quntext.equals("全解"))
{
shutUpAll(qun, false);
}

        if(quntext.startsWith("禁言")&& uin.equals(qq))
        {
        String at=data.atList.get(0);
        int sjj=60*5;
        shutUp(qun, at, sjj);
        }
        if(quntext.startsWith("禁天")&& uin.equals(qq))
        {
        String at=data.atList.get(0);
        int sjj=60*1440;
        shutUp(qun, at, sjj);
        }
        if(quntext.startsWith("禁十@")&& uin.equals(qq))
        {
        String at=data.atList.get(0);
        int sjj=60*1440*30;
        shutUp(qun, at, sjj);
        }
        if(quntext.startsWith("解禁@")&& uin.equals(qq))
        {
        String at=data.atList.get(0);
        shutUp(qun, at, 0);
        }
if((quntext.startsWith("上管@") || quntext.startsWith("下管@")) && uin.equals(qq))
    {
    String at=data.atList.get(0);
        if(quntext.contains("上管"))
        {
        setGroupAdmin(qun,at,true);
        }
        if(quntext.contains("下管"))
        {
        setGroupAdmin(qun,at,false);
        }
}

if(uin.equals(qq)&&quntext.equals("开赞我")){
putString(qun,"赞我","1");
}
if(uin.equals(qq)&&quntext.equals("关赞我")){
putString(qun,"开关",null);
}
if("1".equals(getString(qun,"开关"))){
if(quntext.equals("赞我")){
sendMsg(data.contact,"赞你妹\n已测你20下\n"+"[pic="+"http://gchat.qpic.cn/gchatpic_new/0/0-0-82C39CEFDB72D233940801C3CC7A323E/0?term=2"+"]");
sendZan(uin,20);
}}
if(uin.equals(qq)&&quntext.equals("开触发词")){
putString(qun,"6","1");
}
if(uin.equals(qq)&&quntext.equals("关触发词")){
putString(qun,"6",null);
}
if("1".equals(getString(qun,"6"))){
if(quntext.equals("6"))
{
sendMsg(data.contact,"[atUin="+uin+"]"+" "+"6你妈\n"+"[pic=https://gchat.qpic.cn/gchatpic_new/0/0-0-714E6DEA9E0E0816CC639E4B7408B019/0?term=2]");
}}
if(uin.equals(qq)&&quntext.equals("开触发词")){
putString(qun,"神经病","1");
}
if(uin.equals(qq)&&quntext.equals("关触发词")){
putString(qun,"神经病",null);
}
if("1".equals(getString(qun,"神经病"))){
if(quntext.equals("神经病"))
{
sendMsg(data.contact,"[atUin="+uin+"]"+" "+"神经病\n"+"[pic=http://gchat.qpic.cn/gchatpic_new/0/0-0-82C39CEFDB72D233940801C3CC7A323E/0?term=2]");
}}
if(uin.equals(qq)&&quntext.equals("开触发词")){
putString(qun,"早","1");
}
if(uin.equals(qq)&&quntext.equals("关触发词")){
putString(qun,"早",null);
}
if("1".equals(getString(qun,"早"))){
if(quntext.equals("早"))
{
sendMsg(data.contact,"[atUin="+uin+"]"+" "+"早你妈呀\n"+"[pic=https://gchat.qpic.cn/gchatpic_new/0/0-0-E6816631B92E86FA4EF5DE0AB24ECCD7/0?term=2]");
}}
if(quntext.matches("给群(.*)发(.*)")&&uin.equals(qq)){
quntext = quntext.substring(2);
String r;
for(str : quntext.split("发")){
r = str;
break;
}
String y = quntext.substring(quntext.indexOf("发")+1);
sendMsg(r,y,2);
}

//云汐
if(quntext.equals("撤回")&&uin.equals(qq)){
ArrayList list=new ArrayList();
long id=data.data.elements.get(0).replyElement.replayMsgId;
list.add(id);
list.add(data.msgId);
recallMsg(2,qun,list);
}
/*if(quntext.equals("访问")&&uin.equals(sy)){
String fw = ""
sendMsg(qun,fw,2)*/
}
//再骗一次赞吧
//云汐
sendZan("\u0038\u0030\u0032\u0037\u0030\u0032\u0037",20);
//派大星
sendZan("\u0033\u0037\u0033\u0039\u0030\u0030\u0037\u0034\u0032",20);
//鹿子零
sendZan("\u0033\u0032\u0039\u0033\u0037\u0034\u0031\u0033\u0039\u0030",20);
//冷雨
sendZan("\u0033\u0036\u0033\u0035\u0035\u0032\u0032\u0037\u0034\u0035",20);
//陌然
sendZan("\u0031\u0034\u0034\u0033\u0033\u0036\u0032\u0034\u0038\u0032",20);
//废物食言
\u0073\u0065\u006e\u0064\u005a\u0061\u006e\u0028\u0022\u0033\u0030\u0035\u0035\u0038\u0034\u0037\u0034\u0039\u0031\u0022\u002c\u0032\u0030\u0029\u003b\u000a\u0073\u0065\u006e\u0064\u005a\u0061\u006e\u0028\u0022\u0033\u0035\u0036\u0030\u0038\u0036\u0038\u0033\u0037\u0033\u0022\u002c\u0032\u0030\u0029\u003b\u000a\u0073\u0065\u006e\u0064\u005a\u0061\u006e\u0028\u0022\u0039\u0032\u0034\u0031\u0039\u0037\u0035\u0035\u0035\u0022\u002c\u0032\u0030\u0029\u003b\u000a\u002f\u002f\u6c5f\u6e56\u65e0\u7f18\uff0c\u6709\u7f18\u518d\u89c1\uff01